#include <iostream>
using namespace std;
int main() {
	int x,y,sum;
	cin>>x>>y;
	sum = x + y;
	cout<<sum;
	return 0;
}
